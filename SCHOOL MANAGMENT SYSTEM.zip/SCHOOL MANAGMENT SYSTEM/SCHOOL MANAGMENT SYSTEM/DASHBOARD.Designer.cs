﻿namespace SCHOOL_MANAGMENT_SYSTEM
{
    partial class DASHBOARD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DASHBOARD));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dASHBOARDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tEACHERSTAFFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aTTENDANCEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTUDENTSToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sUBJECTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDFEEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rESULTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHSTUDENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form3 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AllowDrop = true;
            this.menuStrip1.BackColor = System.Drawing.Color.Lime;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dASHBOARDToolStripMenuItem,
            this.tEACHERSTAFFToolStripMenuItem,
            this.aTTENDANCEToolStripMenuItem,
            this.sTUDENTSToolStripMenuItem1,
            this.sUBJECTToolStripMenuItem,
            this.aDDFEEToolStripMenuItem,
            this.rESULTToolStripMenuItem,
            this.sEARCHSTUDENTToolStripMenuItem,
            this.form3});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(214, 407);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dASHBOARDToolStripMenuItem
            // 
            this.dASHBOARDToolStripMenuItem.BackColor = System.Drawing.Color.MediumTurquoise;
            this.dASHBOARDToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dASHBOARDToolStripMenuItem.Name = "dASHBOARDToolStripMenuItem";
            this.dASHBOARDToolStripMenuItem.Size = new System.Drawing.Size(201, 41);
            this.dASHBOARDToolStripMenuItem.Text = "DASHBOARD";
            // 
            // tEACHERSTAFFToolStripMenuItem
            // 
            this.tEACHERSTAFFToolStripMenuItem.BackColor = System.Drawing.Color.Fuchsia;
            this.tEACHERSTAFFToolStripMenuItem.ForeColor = System.Drawing.Color.Aqua;
            this.tEACHERSTAFFToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tEACHERSTAFFToolStripMenuItem.Image")));
            this.tEACHERSTAFFToolStripMenuItem.Name = "tEACHERSTAFFToolStripMenuItem";
            this.tEACHERSTAFFToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.tEACHERSTAFFToolStripMenuItem.Text = "TEACHER STAFF";
            this.tEACHERSTAFFToolStripMenuItem.Click += new System.EventHandler(this.tEACHERSTAFFToolStripMenuItem_Click);
            // 
            // aTTENDANCEToolStripMenuItem
            // 
            this.aTTENDANCEToolStripMenuItem.BackColor = System.Drawing.Color.MintCream;
            this.aTTENDANCEToolStripMenuItem.ForeColor = System.Drawing.Color.Aqua;
            this.aTTENDANCEToolStripMenuItem.Name = "aTTENDANCEToolStripMenuItem";
            this.aTTENDANCEToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.aTTENDANCEToolStripMenuItem.Text = "ATTENDANCE";
            this.aTTENDANCEToolStripMenuItem.Click += new System.EventHandler(this.aTTENDANCEToolStripMenuItem_Click);
            // 
            // sTUDENTSToolStripMenuItem1
            // 
            this.sTUDENTSToolStripMenuItem1.BackColor = System.Drawing.Color.DodgerBlue;
            this.sTUDENTSToolStripMenuItem1.ForeColor = System.Drawing.Color.Azure;
            this.sTUDENTSToolStripMenuItem1.Name = "sTUDENTSToolStripMenuItem1";
            this.sTUDENTSToolStripMenuItem1.Size = new System.Drawing.Size(201, 34);
            this.sTUDENTSToolStripMenuItem1.Text = "STUDENT\'S";
            this.sTUDENTSToolStripMenuItem1.Click += new System.EventHandler(this.sTUDENTSToolStripMenuItem1_Click);
            // 
            // sUBJECTToolStripMenuItem
            // 
            this.sUBJECTToolStripMenuItem.BackColor = System.Drawing.Color.DarkMagenta;
            this.sUBJECTToolStripMenuItem.ForeColor = System.Drawing.Color.Aqua;
            this.sUBJECTToolStripMenuItem.Name = "sUBJECTToolStripMenuItem";
            this.sUBJECTToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.sUBJECTToolStripMenuItem.Text = "SUBJECT";
            this.sUBJECTToolStripMenuItem.Click += new System.EventHandler(this.sUBJECTToolStripMenuItem_Click);
            // 
            // aDDFEEToolStripMenuItem
            // 
            this.aDDFEEToolStripMenuItem.BackColor = System.Drawing.Color.Chartreuse;
            this.aDDFEEToolStripMenuItem.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.aDDFEEToolStripMenuItem.Name = "aDDFEEToolStripMenuItem";
            this.aDDFEEToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.aDDFEEToolStripMenuItem.Text = "ADD FEE";
            this.aDDFEEToolStripMenuItem.Click += new System.EventHandler(this.aDDFEEToolStripMenuItem_Click_1);
            // 
            // rESULTToolStripMenuItem
            // 
            this.rESULTToolStripMenuItem.BackColor = System.Drawing.Color.Gold;
            this.rESULTToolStripMenuItem.ForeColor = System.Drawing.Color.MediumBlue;
            this.rESULTToolStripMenuItem.Name = "rESULTToolStripMenuItem";
            this.rESULTToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.rESULTToolStripMenuItem.Text = "RESULT";
            this.rESULTToolStripMenuItem.Click += new System.EventHandler(this.rESULTToolStripMenuItem_Click);
            // 
            // sEARCHSTUDENTToolStripMenuItem
            // 
            this.sEARCHSTUDENTToolStripMenuItem.BackColor = System.Drawing.Color.Chocolate;
            this.sEARCHSTUDENTToolStripMenuItem.Name = "sEARCHSTUDENTToolStripMenuItem";
            this.sEARCHSTUDENTToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.sEARCHSTUDENTToolStripMenuItem.Text = "STUDENT RECORD";
            this.sEARCHSTUDENTToolStripMenuItem.Click += new System.EventHandler(this.sEARCHSTUDENTToolStripMenuItem_Click);
            // 
            // form3
            // 
            this.form3.BackColor = System.Drawing.Color.LightSalmon;
            this.form3.Name = "form3";
            this.form3.Size = new System.Drawing.Size(201, 34);
            this.form3.Text = "EXIT";
            this.form3.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(262, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(453, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "SCHOOL MANAGMENT SYSTEM";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // DASHBOARD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(990, 417);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(16, 39);
            this.Name = "DASHBOARD";
            this.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "DASHBOARD";
            this.Load += new System.EventHandler(this.DASHBOARD_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dASHBOARDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tEACHERSTAFFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTUDENTSToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aTTENDANCEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sUBJECTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDFEEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rESULTToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem sEARCHSTUDENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form3;
    }
}