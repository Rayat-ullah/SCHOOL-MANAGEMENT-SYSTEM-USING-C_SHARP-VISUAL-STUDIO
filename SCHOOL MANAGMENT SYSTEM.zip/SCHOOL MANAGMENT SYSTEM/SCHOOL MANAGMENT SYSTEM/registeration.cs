﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SCHOOL_MANAGMENT_SYSTEM
{
    public partial class registeration : Form
    {
        public registeration()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SCHOOLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(connectionString);


            try
            {
                conn.Open();
                string query = "INSERT INTO registeration(UserName, Password,ConfirmPassword,FirstName,LastName,Email,PhoneNo,Address) VALUES('" + txtUser.Text + "', '" + txtPass.Text + "', '" + txtConfPass.Text + "', '" + txtFName.Text + "','" + txtFName.Text + "', '" + txtEmail.Text + "','" + txtConfPass.Text + "','" + txtPhone.Text + "''" + txtAddress.Text + "')";
                SqlCommand cmd = new SqlCommand(query, conn);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show(rowsAffected + " registeration added successfully.");
                    txtUser.Text = "";
                    txtPass.Text = "";
                    txtConfPass.Text = "";
                    txtFName.Text = "";
                    txtLName.Text = "";
                    txtPhone.Text = "";
                    txtEmail.Text = "";
                    txtAddress.Text = "";
                }
                else
                {
                    MessageBox.Show("Query execution failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not establish connection with database server. Please try again. Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }

        private void registeration_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sCHOOLDBDataSet3.registeration' table. You can move, or remove it, as needed.
            this.registerationTableAdapter.Fill(this.sCHOOLDBDataSet3.registeration);

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
    }

