﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SCHOOL_MANAGMENT_SYSTEM
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            registeration r=new registeration();
           r.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*String UserName = txbxName.Text.ToString();
          String Password = txbxPass.Text.ToString();

          if(UserName == "Rayat" & Password == "123")
           {
               MessageBox.Show("Successfully");

               DashBord ds = new DashBord();
               ds.Show();


           }
           else
           {
               MessageBox.Show("Please Enter Valid UserName and Password");
           }*/
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SCHOOLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                conn.Open();
                string query = "SELECT *FROM registeration where UserName = '" + txtUser.Text + "' and Password = '" + txtPass.Text + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.ExecuteNonQuery();
                SqlDataReader reader = cmd.ExecuteReader();

                int count = 0;
                while (reader.Read())
                {
                    count = count + 1;
                }
                if (count == 1)
                {
                    MessageBox.Show("User Name and Password correct \n Successfully login");

                    this.Visible = false;
                    //this.Hide();
                   
                    DASHBOARD d = new DASHBOARD();
                    d.ShowDialog();
                }
                else if (count > 1)
                {
                    MessageBox.Show("Duplicate User Name and Password ");
                    txtUser.Clear();
                    txtPass.Clear();
                    txtUser.Focus();
                }
                else if (txtUser.Text == string.Empty || txtPass.Text == string.Empty)
                {
                    MessageBox.Show("Value is Required");
                }
                else
                {
                    MessageBox.Show("Invalid Username Or Password.\n Please try again! ");
                    txtUser.Clear();
                    txtPass.Clear();
                    txtUser.Focus();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not establish connection with database server. Please try again. Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
    }

