﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SCHOOL_MANAGMENT_SYSTEM
{
    public partial class StudentRecord : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SCHOOLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        //ID variable used in Updating and Deleting Record
        int ID = 0;
        public StudentRecord()
        {
            InitializeComponent();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (ID != 0)
            {
                cmd = new SqlCommand("delete AddStudent where ID=@id", conn);
                conn.Open();
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Record Deleted Successfully!");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SCHOOLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                if (txtsname.Text == String.Empty && txtgender.Text == String.Empty)
                {
                    MessageBox.Show("Please insert data first");
                }
                else
                {
                    conn.Open();
                    string query = "INSERT INTO AddStudent(SName,Class,Gender,DOB,Section,Address) VALUES('" + txtsname.Text + "','" + txtclass.Text + "','" + txtgender.Text + "','" + txtdob.Text + "','" + txtsection.Text + "','" + txtaddress.Text + "'); ";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show(rowsAffected + " Record added successfully.");
                        txtsname.Text = "";
                        txtsection.Text = "";
                        txtgender.Text = "";
                        txtdob.Text = "";
                        txtclass.Text = "";
                        txtaddress.Text = "";

                        string query2 = "SELECT * FROM AddStudent";
                        SqlCommand cmd2 = new SqlCommand(query2, conn);
                        SqlDataAdapter da = new SqlDataAdapter(cmd2);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = new BindingSource(dt, null);

                    }
                    else
                        MessageBox.Show("Query execution failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not establish connection with database server.\n Please try again. Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        
    }

        private void StudentRecord_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sCHOOLDBDataSet8.AddStudent' table. You can move, or remove it, as needed.
            //this.addStudentTableAdapter1.Fill(this.sCHOOLDBDataSet8.AddStudent);
            // TODO: This line of code loads data into the 'sCHOOLDBDataSet5.AddStudent' table. You can move, or remove it, as needed.
            SCHOOLDBDataSet5 sCHOOLDBDataSet51 = this.sCHOOLDBDataSet5;
           // addStudentTableAdapter.Fill(sCHOOLDBDataSet51.AddStudent);

        }

        //Display Data in DataGridView  
        private void DisplayData()
        {
            conn.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from AddStudent", conn);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            txtsname.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txtclass.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txtgender.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            txtdob.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            txtsection.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            txtaddress.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SCHOOLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            SqlCommand cmd;
            SqlDataAdapter adapt;
            //ID variable used in Updating and Deleting Record
            if (txtsname.Text != "" && txtclass.Text != "" && txtgender.Text != "")
            {
                cmd = new SqlCommand("update AddStudent set SName=@sname,Class=@class,Gender=@gender,DOB=@dob,Section=@section,Address=@address where ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@sname", txtsname.Text);
                cmd.Parameters.AddWithValue("@class", txtclass.Text);
                cmd.Parameters.AddWithValue("@gender", txtgender.Text);
                cmd.Parameters.AddWithValue("@dob", txtdob.Text);
                cmd.Parameters.AddWithValue("@section", txtsection.Text);
                cmd.Parameters.AddWithValue("@address", txtaddress.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                con.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
        }
        //Clear Data  
         private void ClearData()
         {
               txtsname.Text = "";
               txtsection.Text = "";
               txtgender.Text = "";
               txtdob.Text = "";
               txtclass.Text = "";
               txtaddress.Text = "";
               ID = 0;
         }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }

}
