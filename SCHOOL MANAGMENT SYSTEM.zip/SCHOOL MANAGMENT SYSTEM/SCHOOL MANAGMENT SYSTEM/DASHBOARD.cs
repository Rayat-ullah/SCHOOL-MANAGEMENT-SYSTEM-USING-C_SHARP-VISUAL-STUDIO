﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SCHOOL_MANAGMENT_SYSTEM
{
    public partial class DASHBOARD : Form
    {
        public DASHBOARD()
        {
            InitializeComponent();
        }

        private void aDDFEEToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tEACHERSTAFFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Teacher t=new Teacher();    
            t.ShowDialog();
        }

        private void aTTENDANCEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Attendance a =new Attendance();
            a.ShowDialog();
        }

        private void sTUDENTSToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AddStudent add = new AddStudent();
            add.ShowDialog();
        }

        private void DASHBOARD_Load(object sender, EventArgs e)
        {

        }

        private void sUBJECTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Subject s= new Subject();
            s.ShowDialog();
        }

        private void sEARCHSTUDENTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StudentRecord s=new StudentRecord();
            s.ShowDialog();
        }

        private void aDDFEEToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            ADDFEE F = new ADDFEE();
            F.ShowDialog();
        }

        private void rESULTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RESULT R=new RESULT();
                R.ShowDialog();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
