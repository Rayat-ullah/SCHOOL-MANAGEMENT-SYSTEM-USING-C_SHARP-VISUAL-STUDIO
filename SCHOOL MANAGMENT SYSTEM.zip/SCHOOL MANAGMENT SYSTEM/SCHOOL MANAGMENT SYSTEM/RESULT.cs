﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace SCHOOL_MANAGMENT_SYSTEM
{
    public partial class RESULT : Form
    {
        public RESULT()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SCHOOLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                conn.Open();
                string query = "INSERT INTO RESULT(SName, RegisterationNo, Class,Section,Marks,Dateofresult,Grade ) VALUES('" + txtsname.Text + "', '" + txtregisterationno.Text + "','" + txtclass.Text + "','" + txtsection.Text + "','" + txtmarks.Text + "', '" + txtdateresult.Text + "','" + txtgrade.Text + "')";
                SqlCommand cmd = new SqlCommand(query, conn);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show(rowsAffected + " Result added successfully.");

                    string query2 = "SELECT * FROM RESULT";
                    SqlCommand cmd2 = new SqlCommand(query2, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd2);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);

                }
                   
                else
                    MessageBox.Show("Query execution failed.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not establish connection with database server. Please try again. Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RESULT_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sCHOOLDBDataSet4.RESULT' table. You can move, or remove it, as needed.
            this.rESULTTableAdapter.Fill(this.sCHOOLDBDataSet4.RESULT);

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
   