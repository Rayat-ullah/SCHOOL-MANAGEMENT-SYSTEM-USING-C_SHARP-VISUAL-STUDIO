﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace SCHOOL_MANAGMENT_SYSTEM
{
    public partial class ADDFEE : Form
    {
        public ADDFEE()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SCHOOLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                conn.Open();
                string query = "INSERT INTO ADDFEE(SName, Fee, Section,Class,Date ) VALUES('" + txtsname.Text + "', '" + txtfee.Text + "','" + txtsection.Text + "','" + txtclass.Text + "', '" + txtdate.Text + "')";
                SqlCommand cmd = new SqlCommand(query, conn);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                    MessageBox.Show(rowsAffected + " Fee added successfully.");
                else
                    MessageBox.Show("Query execution failed.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not establish connection with database server. Please try again. Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ADDFEE_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sCHOOLDBDataSet7.ADDFEE' table. You can move, or remove it, as needed.
            this.aDDFEETableAdapter.Fill(this.sCHOOLDBDataSet7.ADDFEE);

        }
    }
}
    
